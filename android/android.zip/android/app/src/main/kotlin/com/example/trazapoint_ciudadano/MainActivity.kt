package com.example.trazapoint_ciudadano

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
